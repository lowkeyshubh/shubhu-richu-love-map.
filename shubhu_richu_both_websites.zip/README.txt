SHUBHU × RICHU — BOTH WEBSITES

Files in this package:
- index.html : interactive love map (main page)
- letter.html : animated sealed welcome letter

TO PUBLISH BOTH ON YOUR EXISTING GITHUB REPOSITORY
1. Open your repository: https://github.com/lowkeyshubh/shubhu-richu-love-map
2. Upload index.html and letter.html into the repository root. If GitHub asks whether to replace the existing index.html, choose replace only if you want this love map as the main homepage.
3. Commit changes. In Settings → Pages, use Deploy from a branch, branch main, folder /(root).
4. Wait until Actions shows a green check for the Pages deployment.
5. The public links should then be:
   Love map: https://lowkeyshubh.github.io/shubhu-richu-love-map/
   Sealed letter: https://lowkeyshubh.github.io/shubhu-richu-love-map/letter.html

IMPORTANT: These links work only after GitHub Pages successfully deploys. I cannot sign in to your GitHub account or publish to it directly from this chat.
